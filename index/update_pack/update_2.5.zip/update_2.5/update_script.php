<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();

//update data in settings table
$settings_datas['description'] = '2.5';
$CI->db->where('type', 'version');
$CI->db->update('settings', $settings_datas);

$settings_data_0 = array('type' => 'active_map', 'description' => 'mapbox');
$CI->db->insert('settings', $settings_data_0);

//INSERT RECAPTCHA SITEKEY
if ($CI->db->get_where('settings', array('type' => 'recaptcha_sitekey'))->num_rows() == 0) {
	$settings_data_1 = array('type' => 'recaptcha_sitekey', 'description' => 'RECAPTCHA_SITEKEY');
	$CI->db->insert('settings', $settings_data_1);
}

//INSERT RECAPTCHA SECRETKEY
if ($CI->db->get_where('settings', array('type' => 'recaptcha_secretkey'))->num_rows() == 0) {
	$settings_data_2 = array('type' => 'recaptcha_secretkey', 'description' => 'RECAPTCHA_SECRETKEY');
	$CI->db->insert('settings', $settings_data_2);
}
?>
